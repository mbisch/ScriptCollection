#!/bin/bash

rm -rf /home/mbisch/mig_cvs2git/jdekis/blob/*
rm -rf /home/mbisch/mig_cvs2git/jdekis/tmp/* 

echo done


