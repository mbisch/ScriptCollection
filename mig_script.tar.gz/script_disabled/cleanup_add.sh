#!/bin/bash

rm -rf /home/mbisch/mig_cvs2git/Add/blob/*
rm -rf /home/mbisch/mig_cvs2git/Add/tmp/* 

echo done


