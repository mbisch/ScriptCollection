#!/bin/bash

rm -rf /home/mbisch/mig_cvs2git/Sql/blob/*
rm -rf /home/mbisch/mig_cvs2git/Sql/tmp/* 

echo done


